# Private Credit Quarter-End Valuation App (ASC 820)

Interactive Streamlit app + three linked Excel workbooks for quarter-end private credit
portfolio valuation under ASC 820 fair value principles. **All data are dummy figures
for illustration only.**

## What's inside

```
├── app.py                          # Streamlit UI
├── valuation.py                    # DCF / yield-method engine (mirrors the Excel models)
├── data/
│   ├── Market_Data_Inputs.xlsx     # Central assumptions: SOFR spot + forward curve,
│   │                               #   spread matrix (rating × seniority, Q1 & Q2 vintages),
│   │                               #   illiquidity premia, benchmark yields
│   ├── PC_Valuation_Q1_2026.xlsx   # Q1 model: Summary, Positions, DCF engine, Recovery, Bridge
│   └── PC_Valuation_Q2_2026.xlsx   # Q2 model (new origination, repayment, watchlist migration)
├── requirements.txt
└── README.md
```

## Methodology

- **Primary method — DCF / yield method.** Per position: quarterly contractual cash flows
  projected off the SOFR forward curve (with floors); PIK capitalizes to the balance and
  repays at bullet maturity. Discount rate = quarter-end spot SOFR + credit spread
  (internal rating × seniority matrix) + illiquidity premium (tranche type) +
  position-specific credit adjustment.
- **Watchlist overlay.** The stressed credit is also valued on a recovery basis
  (EV waterfall, PV'd at a distressed rate over the resolution period) and
  probability-weighted with the yield-method value.
- **Q-over-Q bridge.** Prior-quarter FV → repayments → PIK capitalized → new originations
  → credit-specific moves → market re-mark & accretion → current FV, at portfolio and
  position level (waterfall chart in the app; Bridge tab in Excel).

## App features

- **PIK toggle** — capitalize PIK (base case) vs. cash-pay equivalent
- **Valuation date** picker — re-projects every position's cash-flow horizon
- **Market data vintage** selector — pull Q1 or Q2 quarter-end curves/spreads
- Parallel **spread shock** slider and illiquidity premium on/off for sensitivity
- Summary dashboard, position table with full yield build, per-position drill-down
  (cash-flow schedule + PV chart), and market data viewer

## Run locally

```bash
git clone https://github.com/<your-username>/pc-valuation-app.git
cd pc-valuation-app
pip install -r requirements.txt
streamlit run app.py
```

## Push to GitHub

```bash
git init
git add .
git commit -m "Private credit quarter-end valuation app"
git branch -M main
git remote add origin https://github.com/<your-username>/pc-valuation-app.git
git push -u origin main
```

## Deploy free on Streamlit Community Cloud

1. Push the repo to GitHub (above).
2. Go to https://share.streamlit.io → **New app** → pick the repo, branch `main`, file `app.py`.
3. Deploy — the xlsx files ship with the repo, so no extra setup is needed.

## Notes on the Excel workbooks

- Color convention: **blue** = inputs, **black** = formulas, **green** = same-workbook links,
  **red** = cross-file references, **yellow fill** = key judgment assumptions.
- Each valuation model carries a mirrored `Market_Data` tab (its quarter's vintage from
  `Market_Data_Inputs.xlsx`) so the model recalculates standalone; in a live environment
  you'd re-point those cells to external links.
- The Q2 model's `Bridge` tab embeds Q1 fair values (pasted from the Q1 model) as its
  prior-quarter column; the bridge foots to zero by construction.
